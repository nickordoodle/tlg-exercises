package com.frequency;
//Write a class that contains a method that returns a random integer between 1 and 20 (inclusive).
//
//		Write a client that invokes this method 1000 times and records each result.
//
//		After the 1000 invocations, the client should output the results, showing how many occurrences of each number there were:
//
//		1  was returned 43 times
//		2  was returned 57 times
//		3  was returned 50 times
//		...
//		20 was returned 44 times
//
//		Your results output can look any way you want it, just make it clear.

class FrequencyClient {
	public static void main(String[] args) {
		int[] resultArr = new int[20];
		// Generate 1000 ints and add to array
		for(int i = 0; i < 999; i++){
			// "landing" on the array index implies another value received
			resultArr[(generateRandInt(1, 20) - 1)]++;
		}

		// print values of array
		for(int j = 0; j < resultArr.length; j++){
			System.out.println( (j + 1) + " was returned " + resultArr[j] + " times.");
		}

	}

	private static int generateRandInt(int minimum, int maximum){
		return (int)(Math.random() * ((maximum - minimum) + 1)) + minimum;
	}

}
