public class TelevisionClientEnums {
	public static void main(String[] args) {
		Television tv1 = new Television();

		tv1.setVolume(VolumeLevel.SOFT);
		System.out.println(tv1);

		tv1.setVolume(VolumeLevel.LOUD);
		System.out.println(tv1);

		tv1.setVolume(VolumeLevel.OFF);
		System.out.println(tv1);

		tv1.setVolume(VolumeLevel.MAX);
		System.out.println(tv1);

		tv1.setVolume(VolumeLevel.MEDIUM);
		System.out.println(tv1);
	}
}
