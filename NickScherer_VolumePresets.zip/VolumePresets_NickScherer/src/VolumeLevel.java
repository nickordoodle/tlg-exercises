//		Each preset carries an int value which represents the actual volume value:
//		0, 25, 50, 75, 100, respectively
enum VolumeLevel {
	OFF (0),
	SOFT (25),
	MEDIUM (50),
	LOUD (75),
	MAX (100);

	private final int volume;

	VolumeLevel(int volume){
		this.volume = volume;
	}

	public int getVolume(){
		return this.volume;
	}



}
