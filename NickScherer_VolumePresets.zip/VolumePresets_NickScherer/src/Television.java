/*
* A business class that models the workings of a television.
 */
//Television volume presets via enum
//
//1. Create an "advanced" enum named VolumeLevel, with 5 volume presets: OFF, SOFT, MEDIUM, LOUD, MAX.
//		See Java Part 1 Sessions manual p.131 for an example.
//
//		Each preset carries an int value which represents the actual volume value:
//		0, 25, 50, 75, 100, respectively
//
//		2. Enhance Television to accept a VolumeLevel, in addition to a simple int, for the desired volume.
//		For example:
//
//		Television tv1 = new Television();
//		tv1.setVolume(24);  // this should still work (as before)
//
//		Television tv2 = new Television();
//		tv2.setVolume(VolumeLevel.LOUD);  // new functionality
//
//		3. Implementation notes:
//		a) Internally, the Television's volume should continue to be stored in a simple int field.
//		b) getVolume() should still return an int for the actual volume value, so continuing the example above:
//
//		tv1.getVolume() returns 24
//		tv2.getVolume() returns 75

public class Television {
	public static final int MIN_VOLUME = 0;
	public static final int MAX_VOLUME = 100;
	public static final String[] VALID_BRANDS = {"Samsung", "LG", "Sony", "Toshiba"};

	private String brand;
	private int volume = 10;
	private boolean isMuted = false;
	private int lastVolume;
	private DisplayType displayType = DisplayType.LED;

	public Television(){
	}

	public Television(String brand){
		setBrand(brand);
	}

	public Television(String brand, int volume){
		this(brand); // Delegate to lower constructor
		setVolume(volume); // Delegate to class method for data validation
	}

	public Television(String brand, int volume, DisplayType displayType) {
		this(brand, volume);
		setDisplayType(displayType);
	}

	public Television(String brand, int volume, boolean isMuted, int lastVolume, DisplayType displayType) {
		this(brand, volume);
		setVolume(volume);
		setIsMuted(isMuted);
		setLastVolume(lastVolume);
		setDisplayType(displayType);
	}

	public void turnOn(){
		System.out.println("Turning on your " + brand + " television to volume " + volume);
	}

	public void turnOff(){
		System.out.println("Shutting down...goodbye");
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		boolean isBrandValid = false;
		// Check parameter brand against all Valid Brands
		// if brand does not match any of the valid brands
		// then, otherwise we know a valid brand
		// LG, Samsung ..
		// valid brand = LG
		// .. = Samsung
		for (String validBrand: VALID_BRANDS){
			if(brand.equals(validBrand)){
				isBrandValid = true;
				break;
			}
		}

		// Check the boolean to see if we ever found a valid brand
		if(isBrandValid){
			this.brand = brand;
		} else {
			System.out.println("Invalid brand " + brand +
					" - valid brands are Samsung, LG, Sony, Toshiba");
		}
	}

	public int getVolume() {
		return volume;
	}

	public void setVolume(int volume) {
		if(volume >= MIN_VOLUME && volume <= MAX_VOLUME){
			this.volume = volume;
			this.lastVolume = volume;
		}
		else {
			System.out.println("Invalid volume entered: " + volume + "\nPlease enter " +
					"a value between " + MIN_VOLUME + " and " + MAX_VOLUME);
		}

	}

	public void setVolume(VolumeLevel volumeLevel) {
		this.volume = volumeLevel.getVolume();
		this.lastVolume = volume;
	}

	public DisplayType getDisplayType() {
		return displayType;
	}

	public void setDisplayType(DisplayType displayType) {
		this.displayType = displayType;
	}

	public int getLastVolume() {
		return lastVolume;
	}

	public void setLastVolume(int lastVolume) {
		this.lastVolume = lastVolume;
	}

	public boolean getIsMuted() {
		return isMuted;
	}

	public void setIsMuted(boolean muted) {
		isMuted = muted;
	}

	// Save current volume, set volume to zero
	private void mute(){
		lastVolume = this.volume;
		this.volume = MIN_VOLUME;
		this.isMuted = true;
	}

	private void unMute(){
		this.volume = this.lastVolume;
		this.isMuted = false;
	}

	@Override
	public String toString() {
		return "com.entertainment.Television{" +
				"brand='" + brand + '\'' +
				", volume=" + volume +
				", displayType=" + displayType +
				'}';
	}
}
