/*
 * This code is sample code, provided as-is, and we make no
 * warranties as to its correctness or suitability for
 * any purpose.
 *
 * We hope that it's useful to you.  Enjoy.
 * Copyright LearningPatterns Inc.
 */

/*
 * Lab - Composition
 *
 * This class is the main class, i.e., where the application starts.
 *
 * It instantiates a Television and uses the new channel functionality.
 */

import java.io.Console;

public class TelevisionTest {
	public static final String promptOne = "Please enter your TV Brand [Sony, LG, Samsung, Toshiba]";
	public static final String promptTwo = "Please enter the volume [0-100]";
	public static final String promptThree = "Please enter the display type [LED, OLED, LCD, PLASMA, CRT]";

	public static void main(String[] args) {
		Console console = System.console();
		String answerOne = null;
		String answerTwo = null;
		String answerThree = null;

		Television tv = new Television();
		boolean isValid = false;
		while(!isValid){
			answerOne = console.readLine(promptOne);
			if(tv.isValidBrand(answerOne))
				isValid = true;
			else
				System.out.println("Sorry, " + answerOne + " is not a valid brand.  Please" +
						"enter a valid brand.");
		}

		isValid = false;
		while(!isValid ){
			answerTwo = console.readLine(promptTwo);
			if(tv.isValidVolume(Integer.parseInt(answerTwo)))
				isValid = true;
			else
				System.out.println("Sorry, " + answerTwo + " is not a valid volumne.  Please" +
						"enter a valid volume.");
		}

		isValid = false;
		while(!isValid){
			answerThree = console.readLine(promptThree);
			if(tv.isValidDisplay(answerThree))
				isValid = true;
			else
				System.out.println("Sorry, " + answerThree + " is not a valid display type.  Please" +
						"enter a valid display type.");
		}

		System.out.println("Order successfully submitted for " + answerOne + " "  + answerTwo
			 + " " + answerThree);

	}
}